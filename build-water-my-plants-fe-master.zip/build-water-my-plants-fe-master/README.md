# build-water-my-plants-fe
front-end react repo for water-my-plants
gmg
