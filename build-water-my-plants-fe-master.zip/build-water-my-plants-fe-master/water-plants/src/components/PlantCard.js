import React from 'react'

const PlantCard = () => {
    return (
        <div>
            
        </div>
    )
}

export default PlantCard
