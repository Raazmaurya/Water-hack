// import React from 'react'

// import {connect} from 'react-redux';

// const PlantCardList = () => {
//     return (
//         <div>
            
//         </div>
//     )
// }

// const mapStateToProps = state => {
//     return {
//         plants: state.plants,
//         isFetching: state.isFetching,
//         error: state.error
//     }
// }

// export default connect(mapStateToProps, {}) (PlantCardList)
