import React from "react";

const Home = () => {
    return(
        <div className="home">

         <h1> Build Water My Plants - FrontEnd</h1>
         <img src="https://images.pexels.com/photos/1906439/pexels-photo-1906439.jpeg?cs=srgb&dl=house-plant-plants-pot-plants-1906439.jpg&fm=jpg" alt="succulents"/>


              <div className="logo">
        {/* <img src= "https://lambdaschoolstudents.slack.com/files/UL8BGQNQ6/FPGCJGN56/logo_copy.pnghttps://lambdaschoolstudents.slack.com/files/UL8BGQNQ6/FPGCJGN56/logo_copy.png" alt="logo"/> */}
        </div>
         <h1> Build Water My Plants </h1>
            <img src="https://images.pexels.com/photos/1906439/pexels-photo-1906439.jpeg?cs=srgb&dl=house-plant-plants-pot-plants-1906439.jpg&fm=jpg" alt="succulents"/>

        </div>
    )
}
export default Home
